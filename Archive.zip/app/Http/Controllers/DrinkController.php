<?php


namespace App\Http\Controllers;

use App\Drink;
use Illuminate\Http\Request; // mo hinh Dependency Injection

class DrinkController extends Controller{

	function getDrink(){
		return json_encode(Drink::all());
	}

	function postDrink(Request $request){
		
		var_dump($request->all());
	}

}

?>